# snowflake-wif-test

A small repo for learning how GitHub Actions logs in to Snowflake with
**workload identity federation (WIF)**, with no passwords, keys or secrets.

It uses its own Snowflake test user (`svc_wif_test`), so it never touches
your production `svc_operations_user`.

## What's in here

| File | What it does |
| --- | --- |
| `.github/workflows/test-wif.yml` | The workflow. Grants `id-token: write` and runs the two scripts |
| `snowflake_conn.py` | Gets a token from GitHub (steps 1-2) and logs in to Snowflake with it (step 3) |
| `show_claims.py` | Prints what's written on the token, including the `sub` to paste into Snowflake |
| `test_connection.py` | Logs in, shows who you are, and tests what you can and can't do |
| `setup.sql` | Creates the Snowflake test user, role, warehouse and auth policy |
| `check_logins.sql` | Shows the login and queries from Snowflake's side |
| `cleanup.sql` | Removes everything `setup.sql` created |

## Setup (PowerShell)

Replace `<ORG>` with your GitHub org (or username) and `<SF_ACCOUNT>` with
your Snowflake account identifier, e.g. `ACME-DATA01`. Find it in Snowsight with:

```sql
SELECT CURRENT_ORGANIZATION_NAME() || '-' || CURRENT_ACCOUNT_NAME();
```

### 1. Create the repo and push these files

From inside this folder:

```powershell
git init -b main
git add .
git commit -m "WIF test repo"
gh repo create <ORG>/snowflake-wif-test --private --source . --push
```

### 2. Give this repo its own token subject

This makes the token's `sub` include this repo's ID, so it can't collide with
the subject your production user trusts:

```powershell
'{"use_default": false, "include_claim_keys": ["repository_owner_id", "repository_id", "context"]}' |
  gh api --method PUT /repos/<ORG>/snowflake-wif-test/actions/oidc/customization/sub --input -
```

### 3. Set the two repository variables

Neither is a secret. Use exactly the same audience string in `setup.sql` later.

```powershell
gh variable set SNOWFLAKE_ACCOUNT  --body "<SF_ACCOUNT>" -R <ORG>/snowflake-wif-test
gh variable set SNOWFLAKE_AUDIENCE --body "https://<SF_ACCOUNT>.snowflakecomputing.com" -R <ORG>/snowflake-wif-test
```

### 4. First run: read the token (the login will fail, which is expected)

```powershell
gh workflow run test-wif.yml -R <ORG>/snowflake-wif-test --ref main
gh run watch -R <ORG>/snowflake-wif-test
```

Open the run on github.com (`gh run view -R <ORG>/snowflake-wif-test --web`).
The **Steps 1-2** step prints the claims. Copy the `sub` value. It looks like:

```text
repository_owner_id:123456789:repository_id:987654321:ref:refs/heads/main
```

The **Steps 3-6** step fails because Snowflake doesn't know this subject yet.

### 5. Create the Snowflake side

Open `setup.sql` in a Snowsight worksheet, paste your `sub` into `SUBJECT`
and your audience into `OIDC_AUDIENCE_LIST`, then run it all.

### 6. Second run: it should work

```powershell
gh workflow run test-wif.yml -R <ORG>/snowflake-wif-test --ref main
gh run watch -R <ORG>/snowflake-wif-test
gh run view -R <ORG>/snowflake-wif-test --web
```

The run's **Summary** page shows two tables: the token's claims, and the
Snowflake session (user `SVC_WIF_TEST`, role `WIF_TEST_ROLE`, and the
authorization checks). Then run `check_logins.sql` in Snowsight to see the
same login from Snowflake's side. Look for `WORKLOAD_IDENTITY` in
`first_authentication_factor`.

## Experiments to try

Run each one, read the error, then undo it before the next.

| Experiment | How | What you'll learn |
| --- | --- | --- |
| Run from a branch | `git checkout -b test; git push -u origin test`, then `gh workflow run test-wif.yml -R <ORG>/snowflake-wif-test --ref test` | `sub` ends in `refs/heads/test`, so Snowflake refuses. Only `main` gets in. |
| Wrong audience | `gh variable set SNOWFLAKE_AUDIENCE --body "snowflakecomputing.com" -R <ORG>/snowflake-wif-test` | Tokens are bound to one account. Set it back afterward. |
| No token permission | Delete the `id-token: write` line, commit, run | GitHub won't issue a token at all. Revert afterward. |
| Remove a key | In Snowflake: `REVOKE USAGE ON WAREHOUSE wif_test_wh FROM ROLE wif_test_role;` | Login still works, but queries fail. Authentication and authorization are separate. Re-grant afterward. |

## Cleanup

Run `cleanup.sql` in Snowsight, then:

```powershell
gh repo delete <ORG>/snowflake-wif-test --yes
```

(`gh repo delete` needs an extra scope: `gh auth refresh -h github.com -s delete_repo`.)
